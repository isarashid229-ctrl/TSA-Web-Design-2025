# SOS Pack: Emergency Go‑bag Checklist

- Water (3‑day supply) and non‑perishable food
- First‑aid kit and prescriptions
- Flashlight, batteries, whistle, multi‑tool
- Phone chargers and power bank
- Copies of IDs, insurance, and important contacts
- Cash & coins, local maps
- Clothing & blankets
- Hygiene items, masks, sanitizer
- For kids & pets: supplies, comfort items

More: https://www.ready.gov/kit  |  https://www.redcross.org/get-help/how-to-prepare-for-emergencies/make-a-plan.html
